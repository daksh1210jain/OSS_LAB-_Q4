# Projeto Cardinals
<p align="justify">Bem vindo ao Cardinals, projeto criado pelos alunos das disciplinas de Métodos de Desenvolvimento de Software e Engenharia de Produto de Software da Universidade de Brasília, Campus Gama (FGA).</p>


## Equipe de Gerenciamento
Nome | Email | Git
----------|-------|-------------
Amanda Bezerra |emaildaamandasilva@gmail.com | @amandabezerra
Lucas Costa |	Lucascostaa73@gmail.com | @lucasca73
Miguel Nery	| nery.mik@gmail.com	| @MiguelNery
Marlon Mendes	| marlonciriatico@gmail.com	| @marlonbymendes
Guilherme da Luz	| guilherme.daluz@outlook.com	| @daluzguilherme


## Equipe de Desenvolvimento
Nome | Email | Git
----------|-------|-------------       
Lorrany Azevedo	|lorrany90@gmail.com	| @lorryaze
Gustavo Duarte	|gustavoduartemoreira@gmail.com|	@gustavoduartemoreira
Mateus Augusto	|palitos.11235@gmail.com	| @Mateusas3s
Matheus Gomes 	|matheusgomesf01@gmail.com	| @matheusgomesf
João Pedro  	|connorclone201@gmail.com	| @jpmartins201